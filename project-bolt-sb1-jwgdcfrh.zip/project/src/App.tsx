import React, { useState, useEffect } from 'react';
import { Save, Download, Plus, Trash2, Lock, Users, LogOut, Eye, EyeOff, Filter, BarChart3, Printer, X, Edit2, CheckCircle, Clock, Calendar, Package, Instagram, Archive, FileText, RefreshCw } from 'lucide-react';

const TransportSystem = () => {
  const [rows, setRows] = useState([]);
  const [archivedData, setArchivedData] = useState({});
  const [nextId, setNextId] = useState(1);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [showUserManagement, setShowUserManagement] = useState(false);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    productType: '', vehicleType: '', governorate: '', exitStatus: 'all'
  });
  const [showStats, setShowStats] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [showArchive, setShowArchive] = useState(false);
  const [selectedArchiveMonth, setSelectedArchiveMonth] = useState('');
  const [newUser, setNewUser] = useState({
    username: '', password: '', name: '', role: '',
    permissions: {
      date: false, productType: false, governorate: false, vehicleType: false, loadCapacity: false,
      agent: false, skipCount: false, fridgeNumber: false, accountant: false, driverName: false,
      vehicleCode: false, driverPhone: false, gpsLink: false, exitChecked: false,
      canDelete: false, canAdd: false
    }
  });

  const columns = [
    { key: 'date', label: 'التاريخ' },
    { key: 'productType', label: 'النوعية' },
    { key: 'governorate', label: 'المحافظة' },
    { key: 'vehicleType', label: 'نوع الآلية' },
    { key: 'loadCapacity', label: 'كمية الحمولة' },
    { key: 'agent', label: 'اسم الوكيل' },
    { key: 'skipCount', label: 'عدد السكيب' },
    { key: 'fridgeNumber', label: 'رقم الثلاجة' },
    { key: 'accountant', label: 'المحاسب' },
    { key: 'driverName', label: 'السائق' },
    { key: 'vehicleCode', label: 'رمز الآلية' },
    { key: 'driverPhone', label: 'الهاتف' },
    { key: 'gpsLink', label: 'GPS' },
    { key: 'exitChecked', label: 'الخروجية' }
  ];

  useEffect(() => {
    const defaultUsers = [
      {
        id: 1, username: 'admin', password: 'admin123', name: 'المدير', role: 'مدير النظام', isAdmin: true,
        permissions: { date: true, productType: true, governorate: true, vehicleType: true, loadCapacity: true,
          agent: true, skipCount: true, fridgeNumber: true, accountant: true, driverName: true,
          vehicleCode: true, driverPhone: true, gpsLink: true, exitChecked: true,
          canDelete: true, canAdd: true }
      }
    ];
    setUsers(defaultUsers);

    const savedArchive = localStorage.getItem('archived_data');
    if (savedArchive) {
      setArchivedData(JSON.parse(savedArchive));
    }
  }, []);

  useEffect(() => {
    if (Object.keys(archivedData).length > 0) {
      localStorage.setItem('archived_data', JSON.stringify(archivedData));
    }
  }, [archivedData]);

  const handleLogin = () => {
    const user = users.find(u => u.username === loginUsername && u.password === loginPassword);
    if (user) {
      setCurrentUser(user);
      setIsLoggedIn(true);
      setLoginUsername('');
      setLoginPassword('');
    } else {
      alert('❌ اسم المستخدم أو كلمة المرور غير صحيحة');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setShowUserManagement(false);
    setShowStats(false);
  };

  const hasPermission = (field) => {
    if (!currentUser) return false;
    if (currentUser.isAdmin) return true;
    return currentUser.permissions[field] === true;
  };

  const addNewRow = () => {
    if (!hasPermission('canAdd')) {
      alert('❌ ليس لديك صلاحية إضافة نقلات');
      return;
    }
    const newRow = {
      id: nextId, date: new Date().toLocaleDateString('en-GB'),
      productType: '', governorate: '', vehicleType: '', loadCapacity: '',
      agent: '', skipCount: '', fridgeNumber: '', accountant: '',
      driverName: '', vehicleCode: '', driverPhone: '', gpsLink: '',
      exitChecked: false, createdBy: currentUser.name
    };
    setRows([...rows, newRow]);
    setNextId(nextId + 1);
  };

  const deleteRow = (rowId) => {
    if (!hasPermission('canDelete')) {
      alert('❌ ليس لديك صلاحية حذف النقلات');
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذه النقلة؟')) {
      setRows(rows.filter(row => row.id !== rowId));
    }
  };

  const updateCell = (rowId, field, value) => {
    if (!hasPermission(field)) return;
    setRows(prevRows => prevRows.map(row => row.id === rowId ? { ...row, [field]: value } : row));
  };

  const toggleExit = (rowId) => {
    if (!hasPermission('exitChecked')) return;
    setRows(prevRows => prevRows.map(row => row.id === rowId ? { ...row, exitChecked: !row.exitChecked } : row));
  };

  const getRowColor = (row) => {
    if (row.exitChecked) return 'bg-emerald-50';
    if (row.productType === 'خاص') return 'bg-amber-50';
    if (row.productType === 'بيض تفقيس' || row.productType === 'بيض مائدة') return 'bg-rose-50';
    return 'hover:bg-blue-50';
  };

  const archiveDailyData = () => {
    if (rows.length === 0) {
      alert('❌ لا توجد نقلات لأرشفتها');
      return;
    }

    const today = new Date().toLocaleDateString('en-GB');
    const monthYear = new Date().toLocaleDateString('en-GB', { month: '2-digit', year: 'numeric' });

    const headers = 'ID,التاريخ,النوعية,المحافظة,نوع الآلية,كمية الحمولة,الوكيل,السكيب,الثلاجة,المحاسب,السائق,رمز الآلية,الهاتف,GPS,خروجية\n';
    const csvData = rows.map(row =>
      `${row.id},${row.date},${row.productType || ''},${row.governorate || ''},${row.vehicleType || ''},${row.loadCapacity || ''},${row.agent || ''},${row.skipCount || ''},${row.fridgeNumber || ''},${row.accountant || ''},${row.driverName || ''},${row.vehicleCode || ''},${row.driverPhone || ''},${row.gpsLink || ''},${row.exitChecked ? 'نعم' : 'لا'}`
    ).join('\n');

    const blob = new Blob(['\ufeff' + headers + csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `أرشيف_يومي_${today.replace(/\//g, '-')}.csv`;
    link.click();

    const newArchive = { ...archivedData };
    if (!newArchive[monthYear]) {
      newArchive[monthYear] = [];
    }
    newArchive[monthYear] = [...newArchive[monthYear], ...rows];
    setArchivedData(newArchive);

    setRows([]);
    setNextId(1);

    alert('✓ تم أرشفة البيانات اليومية وتحميل ملف Excel بنجاح!\n✓ البيانات محفوظة في الأرشيف الشهري');
  };

  const archiveMonthlyData = () => {
    const monthYear = new Date().toLocaleDateString('en-GB', { month: '2-digit', year: 'numeric' });
    const monthData = archivedData[monthYear] || [];

    if (monthData.length === 0) {
      alert('❌ لا توجد بيانات مؤرشفة لهذا الشهر');
      return;
    }

    const headers = 'ID,التاريخ,النوعية,المحافظة,نوع الآلية,كمية الحمولة,الوكيل,السكيب,الثلاجة,المحاسب,السائق,رمز الآلية,الهاتف,GPS,خروجية\n';
    const csvData = monthData.map(row =>
      `${row.id},${row.date},${row.productType || ''},${row.governorate || ''},${row.vehicleType || ''},${row.loadCapacity || ''},${row.agent || ''},${row.skipCount || ''},${row.fridgeNumber || ''},${row.accountant || ''},${row.driverName || ''},${row.vehicleCode || ''},${row.driverPhone || ''},${row.gpsLink || ''},${row.exitChecked ? 'نعم' : 'لا'}`
    ).join('\n');

    const blob = new Blob(['\ufeff' + headers + csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `أرشيف_شهري_${monthYear.replace(/\//g, '-')}.csv`;
    link.click();

    alert(`✓ تم تحميل أرشيف شهر ${monthYear} بنجاح!\nعدد النقلات: ${monthData.length}`);
  };

  const startNewDay = () => {
    if (rows.length > 0) {
      if (window.confirm('⚠️ يوجد نقلات لم يتم أرشفتها. هل تريد أرشفتها أولاً؟')) {
        archiveDailyData();
      }
    }

    setRows([]);
    setNextId(1);
    alert('✓ تم بدء يوم جديد بنجاح!');
  };

  const getFilteredRows = () => {
    let filtered = [...rows];
    if (searchTerm) {
      filtered = filtered.filter(row =>
        Object.values(row).some(val => String(val).toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    if (filters.productType) filtered = filtered.filter(row => row.productType === filters.productType);
    if (filters.vehicleType) filtered = filtered.filter(row => row.vehicleType === filters.vehicleType);
    if (filters.governorate) filtered = filtered.filter(row => row.governorate && row.governorate.includes(filters.governorate));
    if (filters.exitStatus === 'exited') filtered = filtered.filter(row => row.exitChecked === true);
    else if (filters.exitStatus === 'notExited') filtered = filtered.filter(row => row.exitChecked === false);
    return filtered;
  };

  const filteredRows = getFilteredRows();

  const getStats = () => {
    const today = new Date().toLocaleDateString('en-GB');
    const todayTrips = rows.filter(r => r.date === today).length;
    const exitedCount = rows.filter(r => r.exitChecked).length;
    return { total: rows.length, today: todayTrips, exited: exitedCount, notExited: rows.length - exitedCount };
  };

  const stats = getStats();

  const printTrip = (row) => {
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    const printContent = `
      <!DOCTYPE html>
      <html dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>نقلة ${row.id}</title>
        <style>
          body { font-family: 'Arial', sans-serif; padding: 30px; background: white; }
          h1 { text-align: center; color: #059669; margin-bottom: 30px; border-bottom: 3px solid #059669; padding-bottom: 10px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          td { padding: 12px; border: 1px solid #ddd; }
          td:first-child { font-weight: bold; background: #f3f4f6; width: 30%; }
          .footer { margin-top: 40px; text-align: center; color: #666; font-size: 14px; }
          @media print { body { padding: 10px; } }
        </style>
      </head>
      <body>
        <h1>ETIHAD - سما كربلاء - نقلة رقم ${row.id}</h1>
        <table>
          <tr><td>التاريخ</td><td>${row.date || ''}</td></tr>
          <tr><td>النوعية</td><td>${row.productType || ''}</td></tr>
          <tr><td>المحافظة</td><td>${row.governorate || ''}</td></tr>
          <tr><td>نوع الآلية</td><td>${row.vehicleType || ''}</td></tr>
          <tr><td>كمية الحمولة</td><td>${row.loadCapacity || ''}</td></tr>
          <tr><td>اسم الوكيل</td><td>${row.agent || ''}</td></tr>
          <tr><td>عدد السكيب</td><td>${row.skipCount || ''}</td></tr>
          <tr><td>رقم الثلاجة</td><td>${row.fridgeNumber || ''}</td></tr>
          <tr><td>المحاسب</td><td>${row.accountant || ''}</td></tr>
          <tr><td>السائق</td><td>${row.driverName || ''}</td></tr>
          <tr><td>رمز الآلية</td><td>${row.vehicleCode || ''}</td></tr>
          <tr><td>الهاتف</td><td>${row.driverPhone || ''}</td></tr>
          <tr><td>GPS</td><td>${row.gpsLink || ''}</td></tr>
          <tr><td>الخروجية</td><td>${row.exitChecked ? '✓ نعم' : '✗ لا'}</td></tr>
        </table>
        <div class="footer">
          <p>تاريخ الطباعة: ${new Date().toLocaleString('ar-IQ')}</p>
        </div>
      </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();

    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  const handleAddUser = () => {
    if (!newUser.username || !newUser.password || !newUser.name) {
      alert('❌ يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    const userExists = users.find(u => u.username === newUser.username && (!editingUser || u.id !== editingUser.id));
    if (userExists) {
      alert('❌ اسم المستخدم موجود مسبقاً');
      return;
    }

    if (editingUser) {
      setUsers(users.map(u => u.id === editingUser.id ? { ...editingUser, ...newUser } : u));
      alert('✓ تم تعديل المستخدم بنجاح!');
    } else {
      const user = { id: users.length + 1, ...newUser, isAdmin: false };
      setUsers([...users, user]);
      alert('✓ تم إضافة المستخدم بنجاح!');
    }

    setNewUser({
      username: '', password: '', name: '', role: '',
      permissions: {
        date: false, productType: false, governorate: false, vehicleType: false, loadCapacity: false,
        agent: false, skipCount: false, fridgeNumber: false, accountant: false, driverName: false,
        vehicleCode: false, driverPhone: false, gpsLink: false, exitChecked: false,
        canDelete: false, canAdd: false
      }
    });
    setEditingUser(null);
    setShowAddUser(false);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setNewUser({
      username: user.username,
      password: user.password,
      name: user.name,
      role: user.role,
      permissions: { ...user.permissions }
    });
    setShowAddUser(true);
  };

  const handleDeleteUser = (userId) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
      setUsers(users.filter(u => u.id !== userId));
      alert('✓ تم حذف المستخدم!');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-slate-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-10 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-block bg-gradient-to-br from-emerald-500 to-teal-600 p-4 rounded-2xl mb-4">
              <Lock className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl font-black text-gray-800 mb-2">ETIHAD</h1>
            <p className="text-xl text-gray-600">سما كربلاء</p>
          </div>
          <div className="space-y-6">
            <div>
              <label className="block text-right text-gray-700 mb-2 font-semibold text-sm">اسم المستخدم</label>
              <input type="text" value={loginUsername} onChange={(e) => setLoginUsername(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl text-right focus:border-blue-500 focus:outline-none" />
            </div>
            <div>
              <label className="block text-right text-gray-700 mb-2 font-semibold text-sm">كلمة المرور</label>
              <div className="relative">
                <input type={showPassword ? "text" : "password"} value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl text-right focus:border-blue-500 focus:outline-none" />
                <button onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <button onClick={handleLogin}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white py-3 rounded-xl font-bold transition-all shadow-lg">
              تسجيل الدخول
            </button>
          </div>
          <div className="mt-8 p-4 bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl border border-gray-200">
            <p className="text-center font-bold text-gray-800 mb-3 text-base">حقوق البرنامج</p>
            <div className="flex items-center justify-center gap-2 text-gray-700">
              <Instagram className="w-5 h-5 text-pink-600" />
              <span className="font-semibold">ameer_eng97</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showArchive) {
    const archiveMonths = Object.keys(archivedData).sort().reverse();
    const selectedData = selectedArchiveMonth ? archivedData[selectedArchiveMonth] : [];

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100" dir="rtl">
        <div className="bg-white shadow-md sticky top-0 z-20 border-b">
          <div className="container mx-auto px-6 py-3 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Archive className="w-8 h-8 text-emerald-600" />
              <h1 className="text-2xl font-bold">الأرشيف</h1>
            </div>
            <button onClick={() => setShowArchive(false)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold">رجوع</button>
          </div>
        </div>

        <div className="container mx-auto px-6 py-6">
          <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
            <h2 className="text-xl font-bold mb-4">اختر الشهر</h2>
            <select value={selectedArchiveMonth} onChange={(e) => setSelectedArchiveMonth(e.target.value)}
              className="w-full px-4 py-3 border-2 rounded-lg text-lg">
              <option value="">-- اختر الشهر --</option>
              {archiveMonths.map(month => (
                <option key={month} value={month}>{month} ({archivedData[month].length} نقلة)</option>
              ))}
            </select>
          </div>

          {selectedData.length > 0 && (
            <div className="bg-white rounded-2xl shadow-xl overflow-x-auto">
              <div className="p-4 bg-slate-100 border-b">
                <h3 className="text-lg font-bold">نقلات شهر {selectedArchiveMonth}</h3>
                <p className="text-sm text-gray-600">عدد النقلات: {selectedData.length}</p>
              </div>
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-700 text-white">
                    <th className="px-3 py-2">ID</th>
                    <th className="px-3 py-2">التاريخ</th>
                    <th className="px-3 py-2">النوعية</th>
                    <th className="px-3 py-2">المحافظة</th>
                    <th className="px-3 py-2">نوع الآلية</th>
                    <th className="px-3 py-2">السائق</th>
                    <th className="px-3 py-2">الخروجية</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedData.map((row, idx) => (
                    <tr key={idx} className="border-b hover:bg-gray-50">
                      <td className="px-3 py-2 font-bold">{row.id}</td>
                      <td className="px-3 py-2">{row.date}</td>
                      <td className="px-3 py-2">{row.productType}</td>
                      <td className="px-3 py-2">{row.governorate}</td>
                      <td className="px-3 py-2">{row.vehicleType}</td>
                      <td className="px-3 py-2">{row.driverName}</td>
                      <td className="px-3 py-2 text-center">
                        {row.exitChecked ? <CheckCircle className="w-5 h-5 text-green-600 mx-auto" /> : <X className="w-5 h-5 text-red-600 mx-auto" />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (showUserManagement && currentUser.isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100" dir="rtl">
        <div className="bg-white shadow-md sticky top-0 z-20 border-b">
          <div className="container mx-auto px-6 py-3 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Users className="w-8 h-8 text-emerald-600" />
              <h1 className="text-2xl font-bold">إدارة المستخدمين</h1>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { setShowAddUser(true); setEditingUser(null); }}
                className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold">
                <Plus className="w-4 h-4" />إضافة مستخدم
              </button>
              <button onClick={() => setShowUserManagement(false)}
                className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold">رجوع</button>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-6 py-6">
          {showAddUser && (
            <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
              <h2 className="text-xl font-bold mb-4">{editingUser ? 'تعديل مستخدم' : 'إضافة مستخدم جديد'}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">اسم المستخدم</label>
                  <input type="text" value={newUser.username} onChange={(e) => setNewUser({...newUser, username: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg focus:border-blue-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">كلمة المرور</label>
                  <input type="text" value={newUser.password} onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg focus:border-blue-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">الاسم الكامل</label>
                  <input type="text" value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg focus:border-blue-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">الوظيفة</label>
                  <input type="text" value={newUser.role} onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg focus:border-blue-500 focus:outline-none" />
                </div>
              </div>
              <div className="mb-4">
                <h3 className="font-bold mb-3">الصلاحيات:</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {columns.map(col => (
                    <label key={col.key} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                      <input type="checkbox" checked={newUser.permissions[col.key]}
                        onChange={() => setNewUser({...newUser, permissions: {...newUser.permissions, [col.key]: !newUser.permissions[col.key]}})}
                        className="w-4 h-4 accent-emerald-600" />
                      <span className="text-sm">{col.label}</span>
                    </label>
                  ))}
                  <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                    <input type="checkbox" checked={newUser.permissions.canAdd}
                      onChange={() => setNewUser({...newUser, permissions: {...newUser.permissions, canAdd: !newUser.permissions.canAdd}})}
                      className="w-4 h-4 accent-emerald-600" />
                    <span className="text-sm font-semibold text-blue-600">إضافة نقلات</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                    <input type="checkbox" checked={newUser.permissions.canDelete}
                      onChange={() => setNewUser({...newUser, permissions: {...newUser.permissions, canDelete: !newUser.permissions.canDelete}})}
                      className="w-4 h-4 accent-emerald-600" />
                    <span className="text-sm font-semibold text-red-600">حذف نقلات</span>
                  </label>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={handleAddUser}
                  className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold">
                  {editingUser ? 'حفظ التعديلات' : 'إضافة'}
                </button>
                <button onClick={() => { setShowAddUser(false); setEditingUser(null); }}
                  className="bg-gray-400 hover:bg-gray-500 text-white px-6 py-2 rounded-lg font-semibold">إلغاء</button>
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl shadow-xl overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700 text-white">
                <tr>
                  <th className="px-4 py-3 text-right">المستخدم</th>
                  <th className="px-4 py-3 text-right">الاسم</th>
                  <th className="px-4 py-3 text-right">الوظيفة</th>
                  <th className="px-4 py-3 text-center">الصلاحيات</th>
                  <th className="px-4 py-3 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-3 font-mono font-bold">{user.username}</td>
                    <td className="px-4 py-3">{user.name}</td>
                    <td className="px-4 py-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${user.isAdmin ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1 justify-center">
                        {columns.map(col => user.permissions[col.key] && (
                          <span key={col.key} className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded text-xs">{col.label}</span>
                        ))}
                        {user.permissions.canAdd && <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">إضافة</span>}
                        {user.permissions.canDelete && <span className="bg-red-100 text-red-700 px-2 py-1 rounded text-xs">حذف</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex gap-2 justify-center">
                        <button onClick={() => handleEditUser(user)}
                          className="text-blue-500 hover:bg-blue-100 p-2 rounded">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {!user.isAdmin && (
                          <button onClick={() => handleDeleteUser(user.id)}
                            className="text-red-500 hover:bg-red-100 p-2 rounded">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  if (showStats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100" dir="rtl">
        <div className="bg-white shadow-md sticky top-0 z-20 border-b">
          <div className="container mx-auto px-6 py-3 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <BarChart3 className="w-8 h-8 text-emerald-600" />
              <h1 className="text-2xl font-bold">الإحصائيات</h1>
            </div>
            <button onClick={() => setShowStats(false)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold">رجوع</button>
          </div>
        </div>
        <div className="container mx-auto px-6 py-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-xl p-6 text-white">
              <Package className="w-12 h-12 mb-3 opacity-80" />
              <p className="text-sm opacity-90">إجمالي النقلات</p>
              <p className="text-4xl font-black">{stats.total}</p>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-xl p-6 text-white">
              <Calendar className="w-12 h-12 mb-3 opacity-80" />
              <p className="text-sm opacity-90">نقلات اليوم</p>
              <p className="text-4xl font-black">{stats.today}</p>
            </div>
            <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl shadow-xl p-6 text-white">
              <CheckCircle className="w-12 h-12 mb-3 opacity-80" />
              <p className="text-sm opacity-90">خرجت</p>
              <p className="text-4xl font-black">{stats.exited}</p>
            </div>
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl shadow-xl p-6 text-white">
              <Clock className="w-12 h-12 mb-3 opacity-80" />
              <p className="text-sm opacity-90">لم تخرج</p>
              <p className="text-4xl font-black">{stats.notExited}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 relative" dir="rtl">
      <div className="bg-white bg-opacity-90 backdrop-blur-md shadow-md sticky top-0 z-20 border-b">
        <div className="container mx-auto px-6 py-3">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="text-3xl font-black bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">ETIHAD</div>
              <div className="h-8 w-px bg-gray-300"></div>
              <div>
                <div className="text-xl font-bold">سما كربلاء</div>
                <div className="text-xs text-gray-500">SAMA KARBALA</div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-lg">
                <span className="text-sm font-semibold">{currentUser.name}</span>
              </div>
              <button onClick={startNewDay}
                className="flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <RefreshCw className="w-4 h-4" />يوم جديد
              </button>
              <button onClick={() => setShowArchive(true)}
                className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <Archive className="w-4 h-4" />الأرشيف
              </button>
              <button onClick={() => setShowStats(true)}
                className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <BarChart3 className="w-4 h-4" />إحصائيات
              </button>
              <button onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <Filter className="w-4 h-4" />فلترة
              </button>
              {currentUser.isAdmin && (
                <button onClick={() => setShowUserManagement(true)}
                  className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                  <Users className="w-4 h-4" />المستخدمين
                </button>
              )}
              {hasPermission('canAdd') && (
                <button onClick={addNewRow}
                  className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                  <Plus className="w-4 h-4" />إضافة
                </button>
              )}
              <button onClick={archiveDailyData}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <Save className="w-4 h-4" />حفظ يومي
              </button>
              <button onClick={archiveMonthlyData}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <FileText className="w-4 h-4" />حفظ شهري
              </button>
              <button onClick={handleLogout}
                className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="بحث في النقلات الحالية..." className="w-full px-4 py-2 border-2 rounded-lg" />
                </div>
                <div>
                  <select value={filters.productType} onChange={(e) => setFilters({...filters, productType: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg">
                    <option value="">كل النوعيات</option>
                    <option value="ريان">ريان</option>
                    <option value="بوادي">بوادي</option>
                    <option value="بيض تفقيس">بيض تفقيس</option>
                    <option value="بيض مائدة">بيض مائدة</option>
                    <option value="خاص">خاص</option>
                  </select>
                </div>
                <div>
                  <select value={filters.exitStatus} onChange={(e) => setFilters({...filters, exitStatus: e.target.value})}
                    className="w-full px-4 py-2 border-2 rounded-lg">
                    <option value="all">الكل</option>
                    <option value="exited">خرجت</option>
                    <option value="notExited">لم تخرج</option>
                  </select>
                </div>
              </div>
              <div className="mt-3 text-sm">
                النتائج: <span className="font-bold">{filteredRows.length}</span> من {rows.length}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="container mx-auto px-6 py-6">
        {rows.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
            <h1 className="text-3xl font-bold mb-4">مرحباً {currentUser.name}</h1>
            <p className="text-gray-600 mb-6">لا توجد نقلات لليوم الحالي</p>
            {hasPermission('canAdd') && (
              <button onClick={addNewRow}
                className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold">
                إضافة نقلة جديدة
              </button>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-xl overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-slate-700 text-white">
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">ID</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">التاريخ</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">النوعية</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">المحافظة</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">نوع الآلية</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">الحمولة</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">الوكيل</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">السكيب</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">الثلاجة</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">المحاسب</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">السائق</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">رمز الآلية</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">الهاتف</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">GPS</th>
                  <th className="px-2 py-2 border-l border-slate-600 text-xs">خروجية</th>
                  <th className="px-2 py-2 text-xs">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row) => (
                  <tr key={row.id} className={getRowColor(row) + ' border-b'}>
                    <td className="px-2 py-2 font-bold border-l border-gray-200 text-xs">{row.id}</td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.date} onChange={(e) => updateCell(row.id, 'date', e.target.value)}
                        disabled={!hasPermission('date')}
                        className="w-20 px-1 py-1 text-center bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <select value={row.productType} onChange={(e) => updateCell(row.id, 'productType', e.target.value)}
                        disabled={!hasPermission('productType')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500">
                        <option value="">اختر</option>
                        <option value="ريان">ريان</option>
                        <option value="بوادي">بوادي</option>
                        <option value="بيض تفقيس">بيض تفقيس</option>
                        <option value="بيض مائدة">بيض مائدة</option>
                        <option value="خاص">خاص</option>
                      </select>
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.governorate} onChange={(e) => updateCell(row.id, 'governorate', e.target.value)}
                        disabled={!hasPermission('governorate')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <select value={row.vehicleType} onChange={(e) => updateCell(row.id, 'vehicleType', e.target.value)}
                        disabled={!hasPermission('vehicleType')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500">
                        <option value="">اختر</option>
                        <option value="تريله">تريله</option>
                        <option value="سحال">سحال</option>
                        <option value="أتيكو">أتيكو</option>
                        <option value="كانتر">كانتر</option>
                        <option value="كانتر قاطع">كانتر قاطع</option>
                      </select>
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.loadCapacity} onChange={(e) => updateCell(row.id, 'loadCapacity', e.target.value)}
                        disabled={!hasPermission('loadCapacity')} maxLength="4"
                        className="w-12 px-1 py-1 text-center bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.agent} onChange={(e) => updateCell(row.id, 'agent', e.target.value)}
                        disabled={!hasPermission('agent')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.skipCount} onChange={(e) => updateCell(row.id, 'skipCount', e.target.value)}
                        disabled={!hasPermission('skipCount')}
                        className="w-12 px-1 py-1 text-center bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.fridgeNumber} onChange={(e) => updateCell(row.id, 'fridgeNumber', e.target.value)}
                        disabled={!hasPermission('fridgeNumber')} maxLength="2"
                        className="w-10 px-1 py-1 text-center bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.accountant} onChange={(e) => updateCell(row.id, 'accountant', e.target.value)}
                        disabled={!hasPermission('accountant')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.driverName} onChange={(e) => updateCell(row.id, 'driverName', e.target.value)}
                        disabled={!hasPermission('driverName')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.vehicleCode} onChange={(e) => updateCell(row.id, 'vehicleCode', e.target.value)}
                        disabled={!hasPermission('vehicleCode')} maxLength="5"
                        className="w-14 px-1 py-1 text-center bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.driverPhone} onChange={(e) => updateCell(row.id, 'driverPhone', e.target.value)}
                        disabled={!hasPermission('driverPhone')}
                        className="w-24 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 border-l border-gray-200">
                      <input type="text" value={row.gpsLink} onChange={(e) => updateCell(row.id, 'gpsLink', e.target.value)}
                        disabled={!hasPermission('gpsLink')}
                        className="w-20 px-1 py-1 bg-transparent rounded text-xs border border-gray-300 focus:border-blue-500" />
                    </td>
                    <td className="px-1 py-2 text-center border-l border-gray-200">
                      <input type="checkbox" checked={row.exitChecked} onChange={() => toggleExit(row.id)}
                        disabled={!hasPermission('exitChecked')}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer" />
                    </td>
                    <td className="px-1 py-2">
                      <div className="flex gap-1 justify-center">
                        <button onClick={() => printTrip(row)} className="text-blue-500 hover:bg-blue-100 p-1 rounded" title="طباعة">
                          <Printer className="w-3 h-3" />
                        </button>
                        {hasPermission('canDelete') && (
                          <button onClick={() => deleteRow(row.id)} className="text-red-500 hover:bg-red-100 p-1 rounded" title="حذف">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="p-4 bg-slate-50 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-rose-50 border-2 border-rose-200 rounded"></span>
                    <span>بيض</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-amber-50 border-2 border-amber-200 rounded"></span>
                    <span>خاص</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-emerald-50 border-2 border-emerald-200 rounded"></span>
                    <span>خروجية</span>
                  </div>
                </div>
                <div className="text-sm">
                  عرض <span className="font-bold">{filteredRows.length}</span> من {rows.length}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TransportSystem;
