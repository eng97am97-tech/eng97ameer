/// <reference types="vite/client" />

declare global {
  interface Window {
    deferredPrompt?: BeforeInstallPromptEvent;
  }
}
