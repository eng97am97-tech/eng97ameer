import { StrictMode, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function Root() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(registration => {
        console.log('ServiceWorker is ready');
        window.addEventListener('beforeinstallprompt', (e) => {
          e.preventDefault();
          if (window.deferredPrompt) {
            window.deferredPrompt.prompt();
          }
        });
      });
    }

    if (navigator.standalone === false) {
      document.documentElement.style.setProperty('--pwa-margin', '0');
    }
  }, []);

  return <App />;
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>
);
